<template>
  <div>
    test
  </div>
</template>

<script>
  export default {
    name: 'FriendRequest'
  }
</script>

<style scoped>

</style>
