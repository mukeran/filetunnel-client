import { sendRequest } from '../index'

export default () => sendRequest({ action: 'alive' })
